#include "logger.h"
#include <iostream>

Logger::Logger(const std::string& filename) : ofs(filename, std::ios::app) {}
Logger::~Logger() { if (ofs.is_open()) ofs.close(); }
void Logger::log(const std::string& message) {
    if (ofs.is_open()) ofs << message << std::endl;
}
