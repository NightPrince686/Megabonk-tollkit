#include <iostream>
#include "logger.h"
#include <thread>
#include <chrono>

// Мини-симуляция: безопасное изменение локальных переменных (для обучения)
int main() {
    Logger logger("miniproject.log");
    logger.log("Program started");

    int health = 100;
    int stamina = 50;
    std::cout << "Starting simulation..." << std::endl;

    for (int t = 0; t < 5; ++t) {
        health -= 7;
        stamina += 4;
        std::cout << "t=" << t << " health=" << health << " stamina=" << stamina << std::endl;
        logger.log("t=" + std::to_string(t) + " health=" + std::to_string(health) + " stamina=" + std::to_string(stamina));
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
    }

    logger.log("Program finished");
    return 0;
}
